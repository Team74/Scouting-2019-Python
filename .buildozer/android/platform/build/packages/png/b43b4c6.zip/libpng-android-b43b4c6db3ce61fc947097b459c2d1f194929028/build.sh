#!/bin/sh
ndk-build NDK_PROJECT_PATH=./ $@
